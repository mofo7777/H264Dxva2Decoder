//----------------------------------------------------------------------------------------------
// Dxva2Renderer.cpp
//----------------------------------------------------------------------------------------------
#include "Stdafx.h"

CDxva2Renderer::CDxva2Renderer() :
	m_pDXVideoProcessor(NULL),
	m_pD3D9Ex(NULL),
	m_pDevice9Ex(NULL),
	m_pDirect3DDeviceManager9(NULL),
	m_pResetToken(0),
	m_dwPicturePresent(0),
	m_DxvaDeviceType(DXVAHD_DEVICE_TYPE_HARDWARE),
	m_InputPool(D3DPOOL_DEFAULT),
	m_bUseBT709(FALSE),
	m_AvgTimePerFrame(0)
{
	ResetDxvaCaps();
	ZeroMemory(&m_LastPresentation, sizeof(SAMPLE_PRESENTATION));
	ZeroMemory(&m_BltParams, sizeof(DXVA2_VideoProcessBltParams));
	ZeroMemory(m_VideoSample, sizeof(DXVA2_VideoSample));
#ifdef USE_DIRECTX9
	ZeroMemory(m_wszMovieFPS, sizeof(m_wszMovieFPS));
	ZeroMemory(m_wszMovieDuration, sizeof(m_wszMovieFPS));
#endif
}

HRESULT CDxva2Renderer::InitDXVA2(const HWND hWnd, const UINT uiWidth, const UINT uiHeight, const UINT uiNumerator, const UINT uiDenominator, DXVA2_VideoDesc& Dxva2Desc, const MFTIME llVideoDuration){

	HRESULT hr;

	// todo
	assert(m_pD3D9Ex == NULL && m_pDevice9Ex == NULL);

	D3DPRESENT_PARAMETERS d3dpp;

	IF_FAILED_RETURN(Direct3DCreate9Ex(D3D_SDK_VERSION, &m_pD3D9Ex));

	ZeroMemory(&d3dpp, sizeof(d3dpp));
	ZeroMemory(&Dxva2Desc, sizeof(DXVA2_VideoDesc));

	d3dpp.BackBufferFormat = D3DFMT_X8R8G8B8;
	d3dpp.BackBufferCount = 1;
	d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
	d3dpp.hDeviceWindow = hWnd;
	d3dpp.BackBufferWidth = uiWidth;
	d3dpp.BackBufferHeight = uiHeight;
	d3dpp.Windowed = TRUE;
	d3dpp.Flags = D3DPRESENTFLAG_VIDEO;

	IF_FAILED_RETURN(m_pD3D9Ex->CreateDeviceEx(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hWnd, D3DCREATE_MULTITHREADED | D3DCREATE_HARDWARE_VERTEXPROCESSING, &d3dpp, NULL, &m_pDevice9Ex));

	IF_FAILED_RETURN(m_pDevice9Ex->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE));
	IF_FAILED_RETURN(m_pDevice9Ex->SetRenderState(D3DRS_ZENABLE, FALSE));
	IF_FAILED_RETURN(m_pDevice9Ex->SetRenderState(D3DRS_LIGHTING, FALSE));

#ifdef USE_DIRECTX9
	RECT rcMovieTimeText = {0, 0, 100, 50};
	IF_FAILED_RETURN(m_cMovieTime.OnRestore(m_pDevice9Ex, rcMovieTimeText, 32.0f));
	IF_FAILED_RETURN(StringCchPrintf(m_wszMovieFPS, 32, L"\n%0.3f fps", uiNumerator / (float)uiDenominator));
	IF_FAILED_RETURN(GetMovieTimeText(m_wszMovieDuration, llVideoDuration));
#endif

	DXVA2_Frequency Dxva2Freq;
	Dxva2Freq.Numerator = uiNumerator;
	Dxva2Freq.Denominator = uiDenominator;

	Dxva2Desc.SampleWidth = uiWidth;
	Dxva2Desc.SampleHeight = uiHeight;

	Dxva2Desc.SampleFormat.SampleFormat = MFVideoInterlace_Progressive;

	Dxva2Desc.Format = static_cast<D3DFORMAT>(D3DFMT_NV12);
	Dxva2Desc.InputSampleFreq = Dxva2Freq;
	Dxva2Desc.OutputFrameFreq = Dxva2Freq;

	IF_FAILED_RETURN(DXVA2CreateDirect3DDeviceManager9(&m_pResetToken, &m_pDirect3DDeviceManager9));

	IF_FAILED_RETURN(m_pDirect3DDeviceManager9->ResetDevice(m_pDevice9Ex, m_pResetToken));

	IF_FAILED_RETURN(InitVideoProcessor(&Dxva2Desc));

	m_BltParams.TargetRect.right = uiWidth;
	m_BltParams.TargetRect.bottom = uiHeight;
	m_BltParams.ConstrictionSize.cx = uiWidth;
	m_BltParams.ConstrictionSize.cy = uiHeight;

	DXVA2_AYUVSample16 color = {0xffff, 0xffff , 0xffff , 0xffff};
	m_BltParams.BackgroundColor = color;

	m_BltParams.DestFormat.SampleFormat = DXVA2_SampleProgressiveFrame;
	m_BltParams.DestFormat.VideoChromaSubsampling = DXVA2_VideoChromaSubsampling_Unknown;
	m_BltParams.DestFormat.NominalRange = DXVA2_NominalRange_16_235;
	m_BltParams.DestFormat.VideoTransferMatrix = DXVA2_VideoTransferMatrix_BT601;
	m_BltParams.DestFormat.VideoLighting = DXVA2_VideoLighting_dim;
	m_BltParams.DestFormat.VideoPrimaries = DXVA2_VideoPrimaries_BT709;
	m_BltParams.DestFormat.VideoTransferFunction = DXVA2_VideoTransFunc_709;

	m_VideoSample[0].SampleFormat.SampleFormat = DXVA2_SampleProgressiveFrame;
	m_VideoSample[0].SampleFormat.VideoChromaSubsampling = DXVA2_VideoChromaSubsampling_Unknown;
	m_VideoSample[0].SampleFormat.NominalRange = DXVA2_NominalRange_16_235;
	m_VideoSample[0].SampleFormat.VideoTransferMatrix = DXVA2_VideoTransferMatrix_BT601;
	m_VideoSample[0].SampleFormat.VideoLighting = DXVA2_VideoLighting_dim;
	m_VideoSample[0].SampleFormat.VideoPrimaries = DXVA2_VideoPrimaries_BT709;
	m_VideoSample[0].SampleFormat.VideoTransferFunction = DXVA2_VideoTransFunc_709;
	m_VideoSample[0].SrcRect = m_BltParams.TargetRect;
	m_VideoSample[0].DstRect = m_BltParams.TargetRect;

	return hr;
}

void CDxva2Renderer::OnRelease(){

	if(m_pDevice9Ex == NULL)
		return;

	m_pResetToken = 0;
	SAFE_RELEASE(m_pDirect3DDeviceManager9);

	ResetDxvaCaps();
	m_dwPicturePresent = 0;
	memset(&m_LastPresentation, 0, sizeof(m_LastPresentation));

#ifdef USE_DIRECTX9
	m_cMovieTime.OnDelete();
	ZeroMemory(m_wszMovieFPS, sizeof(m_wszMovieFPS));
	ZeroMemory(m_wszMovieDuration, sizeof(m_wszMovieFPS));
#endif

	SAFE_RELEASE(m_pD3D9Ex);
	SAFE_RELEASE(m_pDXVideoProcessor);

	m_InputPool = D3DPOOL_DEFAULT;

	if(m_pDevice9Ex){

		ULONG ulCount = m_pDevice9Ex->Release();
		m_pDevice9Ex = NULL;
		assert(ulCount == 0);
	}
}

void CDxva2Renderer::Reset(){

	m_dwPicturePresent = 0;
	memset(&m_LastPresentation, 0, sizeof(m_LastPresentation));
}

HRESULT CDxva2Renderer::RenderFrame(IDirect3DSurface9** pSurface9, const SAMPLE_PRESENTATION& SamplePresentation){

	HRESULT hr = S_OK;
	IDirect3DSurface9* pRT = NULL;

	assert(m_pDXVideoProcessor);

	m_dwPicturePresent++;
	m_LastPresentation.dwDXVA2Index = SamplePresentation.dwDXVA2Index;
	m_LastPresentation.llTime = SamplePresentation.llTime;

	m_BltParams.TargetFrame = m_LastPresentation.llTime;

	m_VideoSample[0].Start = m_LastPresentation.llTime;
	m_VideoSample[0].End = m_LastPresentation.llTime + m_AvgTimePerFrame;
	m_VideoSample[0].SrcSurface = pSurface9[SamplePresentation.dwDXVA2Index];

	try{

		IF_FAILED_THROW(m_pDevice9Ex->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &pRT));

		IF_FAILED_THROW(m_pDXVideoProcessor->VideoProcessBlt(pRT, &m_BltParams, m_VideoSample, 1, NULL));

#ifdef USE_DIRECTX9
		IF_FAILED_THROW(DrawMovieText(m_pDevice9Ex, SamplePresentation.llTime));
#endif

#ifdef HANDLE_DIRECTX_ERROR_UNDOCUMENTED
		hr = m_pDevice9Ex->Present(NULL, NULL, NULL, NULL);

		// Present can return 0x88760872, it is OK to continue.
		// When resizing the window, the rendering thread may fail with this error.
		// So when resizing, the strategy is to pause the video if playing (see WindowsFormProc and WM_ENTERSIZEMOVE/WM_SYSCOMMAND), also, this avoid flickering
		if(hr == DIRECTX_ERROR_UNDOCUMENTED)
			hr = S_OK;
		else
			IF_FAILED_THROW(hr);
#else
		//IF_FAILED_THROW(m_pDevice9Ex->Present(NULL, NULL, NULL, NULL));
		IF_FAILED_THROW(m_pDevice9Ex->PresentEx(NULL, NULL, NULL, NULL, 0));
#endif
	}
	catch(HRESULT){}

	SAFE_RELEASE(pRT);

	return hr;
}

HRESULT CDxva2Renderer::RenderBlackFrame(){

	HRESULT hr;
	IDirect3DSurface9* pRT = NULL;

	IF_FAILED_RETURN(m_pDevice9Ex ? S_OK : E_UNEXPECTED);

	try{

		// Clear the render target seems not to work as expected, ColorFill seems to be OK
		//IF_FAILED_RETURN(m_pDevice9Ex->Clear(0L, NULL, D3DCLEAR_TARGET, 0x00000000, 1.0f, 0L));
		IF_FAILED_THROW(m_pDevice9Ex->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &pRT));
		IF_FAILED_THROW(m_pDevice9Ex->ColorFill(pRT, NULL, 0xff000000));
		//IF_FAILED_THROW(m_pDevice9Ex->Present(NULL, NULL, NULL, NULL));
		IF_FAILED_THROW(m_pDevice9Ex->PresentEx(NULL, NULL, NULL, NULL, 0));

		// It seems we should also clear dxva2 surfaces
		// todo : HANDLE_DIRECTX_ERROR_UNDOCUMENTED
	}
	catch(HRESULT){}

	SAFE_RELEASE(pRT);

	return hr;
}

HRESULT CDxva2Renderer::RenderLastFrame(){

	HRESULT hr;

	IF_FAILED_RETURN(m_pDevice9Ex ? S_OK : E_UNEXPECTED);
	//IF_FAILED_RETURN(m_pDevice9Ex->Present(NULL, NULL, NULL, NULL));
	IF_FAILED_THROW(m_pDevice9Ex->PresentEx(NULL, NULL, NULL, NULL, 0));
	// todo : HANDLE_DIRECTX_ERROR_UNDOCUMENTED

	return hr;
}

HRESULT CDxva2Renderer::RenderLastFramePresentation(IDirect3DSurface9** pSurface9){

	HRESULT hr = S_OK;
	IDirect3DSurface9* pRT = NULL;

	assert(m_pDXVideoProcessor);

	m_BltParams.TargetFrame = m_LastPresentation.llTime;

	m_VideoSample[0].Start = m_LastPresentation.llTime;
	m_VideoSample[0].End = m_LastPresentation.llTime + m_AvgTimePerFrame;
	m_VideoSample[0].SrcSurface = pSurface9[m_LastPresentation.dwDXVA2Index];

	try{

		IF_FAILED_THROW(m_pDevice9Ex->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &pRT));

		IF_FAILED_THROW(m_pDXVideoProcessor->VideoProcessBlt(pRT, &m_BltParams, m_VideoSample, 1, NULL));

#ifdef USE_DIRECTX9
		IF_FAILED_THROW(DrawMovieText(m_pDevice9Ex, m_LastPresentation.llTime));
#endif

#ifdef HANDLE_DIRECTX_ERROR_UNDOCUMENTED
		hr = m_pDevice9Ex->Present(NULL, NULL, NULL, NULL);

		// Present can return 0x88760872, it is OK to continue.
		// When resizing the window, the rendering thread may fail with this error.
		// When resizing, the strategy is to pause the video if playing (see WindowsFormProc and WM_ENTERSIZEMOVE/WM_SYSCOMMAND), also, this avoid flickering
		if(hr == DIRECTX_ERROR_UNDOCUMENTED)
			hr = S_OK;
		else
			IF_FAILED_THROW(hr);
#else
		//IF_FAILED_THROW(m_pDevice9Ex->Present(NULL, NULL, NULL, NULL));
		IF_FAILED_THROW(m_pDevice9Ex->PresentEx(NULL, NULL, NULL, NULL, 0));
#endif
	}
	catch(HRESULT){}

	SAFE_RELEASE(pRT);

	return hr;
}

BOOL CDxva2Renderer::GetDxva2Settings(DXVAHD_FILTER_RANGE_DATA_EX* pFilters, BOOL& bUseBT709){

	if(m_pDXVideoProcessor == NULL)
		return FALSE;

	DXVAHD_FILTER_RANGE_DATA_EX* pFilter = pFilters;

	memcpy(pFilter, &m_RangeBrightness, sizeof(DXVAHD_FILTER_RANGE_DATA_EX));
	pFilter++;
	memcpy(pFilter, &m_RangeContrast, sizeof(DXVAHD_FILTER_RANGE_DATA_EX));
	pFilter++;
	memcpy(pFilter, &m_RangeHue, sizeof(DXVAHD_FILTER_RANGE_DATA_EX));
	pFilter++;
	memcpy(pFilter, &m_RangeSaturation, sizeof(DXVAHD_FILTER_RANGE_DATA_EX));
	pFilter++;
	memcpy(pFilter, &m_RangeNoiseReduction, sizeof(DXVAHD_FILTER_RANGE_DATA_EX));
	pFilter++;
	memcpy(pFilter, &m_RangeEdgeEnhancement, sizeof(DXVAHD_FILTER_RANGE_DATA_EX));
	pFilter++;
	memcpy(pFilter, &m_RangeAnamorphicScaling, sizeof(DXVAHD_FILTER_RANGE_DATA_EX));

	bUseBT709 = m_bUseBT709;

	return TRUE;
}

HRESULT CDxva2Renderer::ResetDxva2Settings(){

	HRESULT hr;
	IF_FAILED_RETURN(m_pDXVideoProcessor ? S_OK : E_UNEXPECTED);

	IF_FAILED_RETURN(SetFilter(ID_FILTER_BRIGHTNESS, m_RangeBrightness.range.DefaultValue.Value));
	IF_FAILED_RETURN(SetFilter(ID_FILTER_CONTRAST, m_RangeContrast.range.DefaultValue.Value));
	IF_FAILED_RETURN(SetFilter(ID_FILTER_HUE, m_RangeHue.range.DefaultValue.Value));
	IF_FAILED_RETURN(SetFilter(ID_FILTER_SATURATION, m_RangeSaturation.range.DefaultValue.Value));
	IF_FAILED_RETURN(SetFilter(ID_FILTER_NOISE_REDUCTION, m_RangeNoiseReduction.range.DefaultValue.Value));
	IF_FAILED_RETURN(SetFilter(ID_FILTER_EDGE_ENHANCEMENT, m_RangeEdgeEnhancement.range.DefaultValue.Value));
	IF_FAILED_RETURN(SetFilter(ID_FILTER_ANAMORPHIC_SCALING, m_RangeAnamorphicScaling.range.DefaultValue.Value));

	SetBT709(m_bUseBT709 = FALSE);

	return hr;
}

INT ComputeLongSteps(DXVA2_ValueRange &range)
{
	float f_step = DXVA2FixedToFloat(range.StepSize);

	if(f_step == 0.0)
		return 0;

	float f_max = DXVA2FixedToFloat(range.MaxValue);
	float f_min = DXVA2FixedToFloat(range.MinValue);
	INT steps = INT((f_max - f_min) / f_step / 32);

	return max(steps, 1);
}

HRESULT CDxva2Renderer::SetFilter(const UINT uiItem, const INT iValue){

	HRESULT hr;
	IF_FAILED_RETURN(m_pDXVideoProcessor ? S_OK : E_UNEXPECTED);

	DXVAHD_FILTER_RANGE_DATA_EX* pRangeDataEx = NULL;
	DXVA2_Fixed32* pFixed = NULL;

	if(uiItem == ID_FILTER_BRIGHTNESS){
		pFixed = &m_BltParams.ProcAmpValues.Brightness;
		pRangeDataEx = &m_RangeBrightness;
	}
	else if(uiItem == ID_FILTER_CONTRAST){
		pFixed = &m_BltParams.ProcAmpValues.Contrast;
		pRangeDataEx = &m_RangeContrast;
	}
	else if(uiItem == ID_FILTER_HUE){
		pFixed = &m_BltParams.ProcAmpValues.Hue;
		pRangeDataEx = &m_RangeHue;
	}
	else if(uiItem == ID_FILTER_SATURATION){
		pFixed = &m_BltParams.ProcAmpValues.Saturation;
		pRangeDataEx = &m_RangeSaturation;
	}
	else if(uiItem == ID_FILTER_NOISE_REDUCTION){
		pRangeDataEx = &m_RangeNoiseReduction;
	}
	else if(uiItem == ID_FILTER_EDGE_ENHANCEMENT){
		pRangeDataEx = &m_RangeEdgeEnhancement;
	}
	else if(uiItem == ID_FILTER_ANAMORPHIC_SCALING){
		pRangeDataEx = &m_RangeAnamorphicScaling;
	}
	else if(uiItem == IDC_RADIO_BT601){
		return SetBT709(iValue);
	}
	else{
		IF_FAILED_RETURN(E_FAIL);
	}

	if(pFixed == NULL|| pRangeDataEx->bAvailable == FALSE)
		return hr;

	if (pRangeDataEx->bHd == TRUE)
	{
		//
	}
	else
	{
		DXVA2_Fixed32 dValue;
		dValue.Value = (SHORT)iValue;

		if (iValue < 0)
			dValue.Fraction = pRangeDataEx->range.MinValue.Fraction;
		else
			dValue.Fraction = pRangeDataEx->range.MaxValue.Fraction;

		float f_value = DXVA2FixedToFloat(dValue);
		float f_max = DXVA2FixedToFloat(pRangeDataEx->range.MaxValue);
		float f_min = DXVA2FixedToFloat(pRangeDataEx->range.MinValue);

		f_value = min(max(f_value, f_min), f_max);
		*pFixed = DXVA2FloatToFixed(f_value);
	}

	return hr;
}

HRESULT CDxva2Renderer::InitVideoProcessor(const DXVA2_VideoDesc* pDxva2Desc){

	HRESULT hr;

	IDirectXVideoProcessorService* pDXVideoProcessorService = NULL;
	UINT uiCount;
	GUID* guids = NULL;
	GUID guid;

	IF_FAILED_RETURN(pDxva2Desc ? S_OK : E_POINTER);

	try{

		IF_FAILED_THROW(DXVA2CreateVideoService(m_pDevice9Ex, IID_PPV_ARGS(&pDXVideoProcessorService)));

		IF_FAILED_THROW(pDXVideoProcessorService->GetVideoProcessorDeviceGuids(pDxva2Desc, &uiCount, &guids));

		for(UINT ui = 0; ui < uiCount; ui++)
		{
			guid = guids[ui];
			hr = CreateDXVA2VPDevice(pDXVideoProcessorService, pDxva2Desc, guid);

			if (hr == S_OK)
				break;
		}

		IF_FAILED_THROW(hr);

		IF_FAILED_THROW(ConfigureVideoProcessor(pDXVideoProcessorService, pDxva2Desc, guid));

		IF_FAILED_THROW(pDXVideoProcessorService->CreateVideoProcessor(guid, pDxva2Desc, D3DFMT_X8R8G8B8, 0, &m_pDXVideoProcessor));

		IF_FAILED_THROW(m_pDevice9Ex->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_ARGB(255, 0, 0, 0), 1.0f, 0));
	}
	catch(HRESULT){}

	CoTaskMemFree(guids);
	SAFE_RELEASE(pDXVideoProcessorService);

	return hr;
}

HRESULT CDxva2Renderer::CreateDXVA2VPDevice(IDirectXVideoProcessorService* pDXVideoProcessorService, const DXVA2_VideoDesc* pDxva2Desc, REFGUID guid){

	HRESULT hr;

	UINT uiIndex;
	UINT uiCount;
	D3DFORMAT* pFormats = NULL;
	DXVA2_VideoProcessorCaps pVPCaps = {0};

	IF_FAILED_RETURN(pDXVideoProcessorService && pDxva2Desc ? S_OK : E_POINTER);

	try{

		IF_FAILED_THROW(pDXVideoProcessorService->GetVideoProcessorRenderTargets(guid, pDxva2Desc, &uiCount, &pFormats));

		for (uiIndex = 0; uiIndex < uiCount; uiIndex++)
		{
			if(pFormats[uiIndex] == D3DFMT_X8R8G8B8)
			{
				break;
			}
		}

		IF_FAILED_THROW(uiIndex == uiCount ? E_FAIL : S_OK);

		IF_FAILED_THROW(pDXVideoProcessorService->GetVideoProcessorCaps(guid, pDxva2Desc, D3DFMT_X8R8G8B8, &pVPCaps));

		IF_FAILED_THROW(pVPCaps.DeviceCaps == DXVA2_VPDev_HardwareDevice ? S_OK : E_FAIL);
		IF_FAILED_THROW((pVPCaps.VideoProcessorOperations & DXVA2_VideoProcess_YUV2RGB) == DXVA2_VideoProcess_YUV2RGB ? S_OK : E_FAIL);
		IF_FAILED_THROW(pVPCaps.NumForwardRefSamples > 0 || pVPCaps.NumBackwardRefSamples > 0 ? E_FAIL : S_OK);

		m_RangeBrightness.bAvailable = pVPCaps.ProcAmpControlCaps & DXVA2_ProcAmp_Brightness ? TRUE : FALSE;
		m_RangeContrast.bAvailable = pVPCaps.ProcAmpControlCaps & DXVA2_ProcAmp_Contrast ? TRUE : FALSE;
		m_RangeHue.bAvailable = pVPCaps.ProcAmpControlCaps & DXVA2_ProcAmp_Hue ? TRUE : FALSE;
		m_RangeSaturation.bAvailable = pVPCaps.ProcAmpControlCaps & DXVA2_ProcAmp_Saturation ? TRUE : FALSE;
		// todo
		m_RangeNoiseReduction.bAvailable = FALSE;
		m_RangeEdgeEnhancement.bAvailable = FALSE;
		m_RangeAnamorphicScaling.bAvailable = FALSE;

		// Informative
		m_BltStateAlphaFill.bAvailable = FALSE;
		m_StateConstriction.bAvailable = FALSE;
		m_StreamStateLumaKey.bAvailable = FALSE;
		m_StreamStateAlpha.bAvailable = FALSE;

		m_InputPool = pVPCaps.InputPool;
	}
	catch(HRESULT){}

	CoTaskMemFree(pFormats);

	return hr;
}

HRESULT CDxva2Renderer::ConfigureVideoProcessor(IDirectXVideoProcessorService* pDXVideoProcessorService, const DXVA2_VideoDesc* pDxva2Desc, REFGUID guid){

	HRESULT hr = S_OK;

	IF_FAILED_RETURN(GetDxva2Filter(pDXVideoProcessorService, pDxva2Desc, guid, m_BltParams.ProcAmpValues.Brightness, DXVA2_ProcAmp_Brightness, &m_RangeBrightness));
	IF_FAILED_RETURN(GetDxva2Filter(pDXVideoProcessorService, pDxva2Desc, guid, m_BltParams.ProcAmpValues.Contrast, DXVA2_ProcAmp_Contrast, &m_RangeContrast));
	IF_FAILED_RETURN(GetDxva2Filter(pDXVideoProcessorService, pDxva2Desc, guid, m_BltParams.ProcAmpValues.Hue, DXVA2_ProcAmp_Hue, &m_RangeHue));
	IF_FAILED_RETURN(GetDxva2Filter(pDXVideoProcessorService, pDxva2Desc, guid, m_BltParams.ProcAmpValues.Saturation, DXVA2_ProcAmp_Saturation, &m_RangeSaturation));
	//IF_FAILED_RETURN(GetDxva2Filter(pDXVideoProcessorService, DXVAHD_FILTER_NOISE_REDUCTION, &m_RangeNoiseReduction));
	//IF_FAILED_RETURN(GetDxva2Filter(pDXVideoProcessorService, DXVAHD_FILTER_EDGE_ENHANCEMENT, &m_RangeEdgeEnhancement));
	//IF_FAILED_RETURN(GetDxva2Filter(pDXVideoProcessorService, DXVAHD_FILTER_ANAMORPHIC_SCALING, &m_RangeAnamorphicScaling));

	return hr;
}

void CDxva2Renderer::ResetDxvaCaps(){

	memset(&m_RangeBrightness, 0, sizeof(m_RangeBrightness));
	memset(&m_RangeContrast, 0, sizeof(m_RangeContrast));
	memset(&m_RangeHue, 0, sizeof(m_RangeHue));
	memset(&m_RangeSaturation, 0, sizeof(m_RangeSaturation));
	memset(&m_RangeNoiseReduction, 0, sizeof(m_RangeNoiseReduction));
	memset(&m_RangeEdgeEnhancement, 0, sizeof(m_RangeEdgeEnhancement));
	memset(&m_RangeAnamorphicScaling, 0, sizeof(m_RangeAnamorphicScaling));
	memset(&m_BltStateAlphaFill, 0, sizeof(m_BltStateAlphaFill));
	memset(&m_StateConstriction, 0, sizeof(m_StateConstriction));
	memset(&m_StreamStateLumaKey, 0, sizeof(m_StreamStateLumaKey));
	memset(&m_StreamStateAlpha, 0, sizeof(m_StreamStateAlpha));
}

HRESULT CDxva2Renderer::GetDxva2Filter(IDirectXVideoProcessorService* pDXVideoProcessorService, const DXVA2_VideoDesc* pDxva2Desc, REFGUID guid, DXVA2_Fixed32& pFilter, const UINT uiFilter, DXVAHD_FILTER_RANGE_DATA_EX* pFilterRange){

	HRESULT hr = S_OK;
	DXVA2_ValueRange Dxva2Range;

	if(pFilterRange && pFilterRange->bAvailable){

		IF_FAILED_RETURN(pDXVideoProcessorService->GetProcAmpRange(guid, pDxva2Desc, D3DFMT_X8R8G8B8, uiFilter, &Dxva2Range));

		pFilter = Dxva2Range.DefaultValue;
		pFilterRange->bHd = FALSE;
		pFilterRange->range = Dxva2Range;
		pFilterRange->iCurrent = Dxva2Range.DefaultValue.Value;
	}

	return hr;
}

HRESULT CDxva2Renderer::SetBT709(const BOOL bUseBT709){

	HRESULT hr;
	IF_FAILED_RETURN(m_pDXVideoProcessor ? S_OK : E_UNEXPECTED);

	m_BltParams.DestFormat.VideoTransferMatrix = bUseBT709 ? DXVA2_VideoTransferMatrix_BT709 : DXVA2_VideoTransferMatrix_BT601;
	m_VideoSample[0].SampleFormat.VideoTransferMatrix = m_BltParams.DestFormat.VideoTransferMatrix;

	m_bUseBT709 = bUseBT709;

	return hr;
}

#ifdef USE_DIRECTX9

HRESULT CDxva2Renderer::DrawMovieText(IDirect3DDevice9Ex* pDevice9Ex, const LONGLONG llMovieTime){

	HRESULT hr;
	WCHAR wszMovieTime[32];
	WCHAR wszText[96];

	IF_FAILED_RETURN(GetMovieTimeText(wszMovieTime, llMovieTime));
	IF_FAILED_RETURN(StringCchPrintf(wszText, 96, L"%s%s\n%s", wszMovieTime, m_wszMovieFPS, m_wszMovieDuration));

	IF_FAILED_RETURN(pDevice9Ex->BeginScene());
	IF_FAILED_RETURN(m_cMovieTime.OnRender(wszText));
	IF_FAILED_RETURN(pDevice9Ex->EndScene());

	return hr;
}

HRESULT CDxva2Renderer::GetMovieTimeText(STRSAFE_LPWSTR wszBuffer, const LONGLONG llTime){

	HRESULT hr = S_OK;
	MFTIME Hours = 0;
	MFTIME Minutes = 0;
	MFTIME Seconds = 0;
	MFTIME MilliSeconds = 0;

	if(llTime < ONE_SECOND){

		MilliSeconds = llTime / ONE_MSEC;
	}
	else if(llTime < ONE_MINUTE){

		Seconds = llTime / ONE_SECOND;
		MilliSeconds = (llTime - (Seconds * ONE_SECOND)) / ONE_MSEC;
	}
	else if(llTime < ONE_HOUR){

		Minutes = llTime / ONE_MINUTE;
		LONGLONG llMinutes = Minutes * ONE_MINUTE;
		Seconds = (llTime - llMinutes) / ONE_SECOND;
		MilliSeconds = (llTime - (llMinutes + (Seconds * ONE_SECOND))) / ONE_MSEC;
	}
	else if(llTime < ONE_DAY){

		Hours = llTime / ONE_HOUR;
		LONGLONG llHours = Hours * ONE_HOUR;
		Minutes = (llTime - llHours) / ONE_MINUTE;
		LONGLONG llMinutes = Minutes * ONE_MINUTE;
		Seconds = (llTime - (llHours + llMinutes)) / ONE_SECOND;
		MilliSeconds = (llTime - (llHours + llMinutes + (Seconds * ONE_SECOND))) / ONE_MSEC;
	}
	else{

		memcpy(wszBuffer, L"Time more than one day", 46);
		return hr;
	}

	IF_FAILED_RETURN(StringCchPrintf(wszBuffer, 32, L"%02dh:%02dmn:%02ds:%03dms", (int)Hours, (int)Minutes, (int)Seconds, MilliSeconds));

	return hr;
}

#endif